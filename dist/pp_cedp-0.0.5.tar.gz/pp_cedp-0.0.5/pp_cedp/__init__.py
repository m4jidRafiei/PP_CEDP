from pp_cedp import CEDP,Utils

__name__ = 'pp_cedp'
__version__ = '0.0.5'
__doc__ = "Privacy-Preserving Continuous Event Data Publishing"
__author__ = 'Majid Rafiei'
__author_email__ = 'majid.rafiei@pads.rwth-aachen.de'
__maintainer__ = 'Majid Rafiei'
__maintainer_email__ = "majid.rafiei@pads.rwth-aachen.de"